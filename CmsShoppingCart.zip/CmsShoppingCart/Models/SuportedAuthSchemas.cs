﻿using System.Collections.Generic;
using System.Security.Claims;

namespace CmsShoppingCart.WebApp.Models
{
    public static class SuportedAuthSchemas
    {
        public static string Okta = "Okta";

        public static string Auth0 = "Auth0";
    }
}
