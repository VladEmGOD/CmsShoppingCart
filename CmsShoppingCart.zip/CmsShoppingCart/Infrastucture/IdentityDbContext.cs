﻿namespace CmsShoppingCart.WebApp.Infrastucture
{
    public class IdentityDbContext
    {
    }
}